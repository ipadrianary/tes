import 'package:flutter/material.dart';

void main() => runApp(MLBBCounterApp());

class MLBBCounterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MLBB Hero Counter',
      theme: ThemeData.dark(),
      home: HeroListPage(),
    );
  }
}

class HeroListPage extends StatelessWidget {
  final List<HeroData> heroes = [
    HeroData(
      name: 'Hayabusa',
      counters: ['Khufra', 'Chou', 'Saber'],
      items: ['Antique Cuirass', 'Dominance Ice'],
      strategy:
          'Gunakan hero CC. Jangan biarkan Hayabusa split push. Fokus clear lane.'
    ),
    HeroData(
      name: 'Alice',
      counters: ['Esmeralda', 'Valir', 'Helcurt'],
      items: ['Necklace of Durance', 'Sea Halberd'],
      strategy:
          'Gank Alice sejak early. Jangan biarkan dia farming dan stack.'
    ),
    HeroData(
      name: 'Lesley',
      counters: ['Natalia', 'Lancelot', 'Saber'],
      items: ['Wind of Nature', 'Immortality'],
      strategy:
          'Gunakan assassin burst. Lesley lemah terhadap hero yang bisa gap cepat.'
    ),
    HeroData(
      name: 'Gusion',
      counters: ['Chou', 'Kaja', 'Khufra'],
      items: ['Athena’s Shield', 'Antique Cuirass'],
      strategy:
          'Tangkap Gusion dengan CC. Jangan biarkan dia snowball dari early.'
    ),
    HeroData(
      name: 'Johnson',
      counters: ['Valir', 'Diggie', 'Karrie'],
      items: ['Winter Truncheon', 'Dominance Ice'],
      strategy:
          'Hindari tabrakan mobil. Gunakan hero yang bisa lepas dari stun.'
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('MLBB Hero Counter')),
      body: ListView.builder(
        itemCount: heroes.length,
        itemBuilder: (context, index) {
          final hero = heroes[index];
          return ListTile(
            title: Text(hero.name),
            subtitle: Text('Counter: ${hero.counters.join(", ")}'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => HeroDetailPage(hero: hero),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class HeroDetailPage extends StatelessWidget {
  final HeroData hero;

  HeroDetailPage({required this.hero});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(hero.name)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Counter oleh:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(hero.counters.join(", ")),
            SizedBox(height: 16),
            Text('Item Rekomendasi:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(hero.items.join(", ")),
            SizedBox(height: 16),
            Text('Strategi:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(hero.strategy),
          ],
        ),
      ),
    );
  }
}

class HeroData {
  final String name;
  final List<String> counters;
  final List<String> items;
  final String strategy;

  HeroData({
    required this.name,
    required this.counters,
    required this.items,
    required this.strategy,
  });
}